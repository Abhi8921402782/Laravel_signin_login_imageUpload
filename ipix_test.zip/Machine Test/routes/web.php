<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
// IPIX project
Route::view('adminsignup/','laravel_crud/adminsignup');

Route::post('adminsignup/',[SampleController::class,'fnAdminSignup']);

Route::view('adminlogin/','laravel_crud/adminlogin');

Route::post('adminlogin/',[SampleController::class,'fnAdminLogin']);

Route::get('admindashboard/',[SampleController::class,'fnAdminDash']);

Route::post('admindashboard/',[SampleController::class,'fnAdminFileUpload']);
