<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class SampleController extends Controller
{
    // IPIX project
    // Admin SignUp
    function fnAdminSignup(Request $request){
            $name=$request->name;
            $address=$request->address;
            $email=$request->email;
            $username=$request->username;
            $password=$request->password;
    
            $admin=DB::table('admin')->insert([
                'admin_name'=>$name,
                'admin_address'=>$address,
                'admin_mail'=>$email,
                'admin_username'=>$username,
                'admin_password'=>$password
            ]);
            if($admin){
                return view('laravel_crud/adminsignup',['message'=>'Admin registered successfully']);
            }
            else{
                return view('laravel_crud/adminsignup',['message'=>'error']);
            }
        } 
        // Admin Login
        function fnAdminLogin(Request $request){
            $username=$request->login;
            $password=$request->password;
            $admin=DB::table('admin')->where('admin_username',$username)->where('admin_password',$password)->first();
            if($admin){
                $request->session()->put('admin_id',$admin->id);
                return redirect('admindashboard/');
            }
            else{
                return view('laravel_crud/adminlogin',['message'=>'Incorrect Input']);
            }
        }
        // Admin Dashboard
        function fnAdminDash(Request $request){
            if(session()->has('admin_id')){
                $id=$request->session()->get('admin_id');
                $admin=DB::table('admin')->where('id',$id)->first();
                return view('laravel_crud/admindashboard',['admin_data'=>$admin]);
    
    
            }
            else{
                return view('laravel_crud/adminlogin',['message'=>'Please Login']);
            }
            
        }
        // Uploadin Image
        function fnAdminFileUpload(Request $request){
            $img="laravelproj1".time().".".$request->image->getClientOriginalExtension();
            echo $img;
            $request->image->storeAs('public/imageupload',$img);
            $admin=DB::table('adminprofile')->insert([
                "image"=>$img
            ]);
            if($admin){
                return view('laravel_crud/fileupload',['imageupload'=>'Image Uploaded']);
            }
            else{
                return view('laravel_crud/fileupload',['imageupload'=>'Error']);
            }
        }
    }