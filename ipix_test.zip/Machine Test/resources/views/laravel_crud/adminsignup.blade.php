<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin SignUp</title>
</head>
<body>
    <h1>Admin SignUp</h1>
<form action="" method="post">
        @csrf
        <input type="text" name="name" id="name" placeholder="Enter the Name"><br><br>
        <textarea name="address" id="address" cols="30" rows="10" placeholder="Enter address"></textarea><br><br>
        <input type="email" name="email" id="email" placeholder="Enter your mail"><br><br>
        <input type="text" name="username" id="username" placeholder="Enter username"><br><br>
        <input type="password" name="password" id="password" placeholder="Enter your password"><br><br>
        <input type="submit" onclick="function1()" value="Submit">
        <p>@if(isset($message) )
            {{$message}} 
            @endif</p>
    </form>

    <script>
        function function1() {
            var name = document.getElementById("name").value;
            var address = document.getElementById("address").value;
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            if (name == "") {
                alert("Name must be filled out");
                return false;
            }
            if (address == ""){
                alert ("Address field is required.");
                return false;
            }
            if(email == ""){
                alert("Email Field Is Required!");
                return false;
            }
            if(password == ""){
                alert("Password Must Be Filled Out!");
            }
        }
    </script>
</body>
</html>