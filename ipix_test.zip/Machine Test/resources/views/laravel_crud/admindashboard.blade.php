<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Welcome</h1>
    <table>
        <tr>
            <th>Name</th>
            <th>{{$admin_data->admin_name}}</th>
        </tr>
        <tr>
            <th>Address</th>
            <th>{{$admin_data->admin_address}}</th>
        </tr>
    </table>
    <br><br><hr><br><br>
    <form action="" method="post" enctype="multipart/form-data">
        @csrf
        <input type="file" name="image" id=""><br>
        <input type="submit" value="submit">
        @if(isset($imageupload))
                <p>{{$imageupload}}</p>
                
            @endif
    </form>
</body>
</html>