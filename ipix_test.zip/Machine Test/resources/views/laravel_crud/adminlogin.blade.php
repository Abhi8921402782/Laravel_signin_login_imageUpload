<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Admin Login</h1>
    <form action="" method="post">
        @csrf
        <input type="text" name="login" placeholder="Enter Username"><br><br>
        <input type="password" name="password" placeholder="Enter Password"><br><br>
        <input type="submit" value="Login"><br>
        
            @if(isset($message))
                <p>{{$message}}</p>
                
            @endif
        
    </form>
    
</body>
</html>